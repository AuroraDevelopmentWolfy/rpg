#!/data/data/com.termux/files/usr/bin/bash

# Lépj a projekt gyökérbe
cd ~/rpg || exit 1

echo "[1/5] Létrehozom a gradle/wrapper mappát..."
mkdir -p gradle/wrapper

echo "[2/5] Létrehozom a gradle-wrapper.properties fájlt..."
cat > gradle/wrapper/gradle-wrapper.properties <<EOF
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.4-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
EOF

echo "[3/5] Letöltöm a gradle-wrapper.jar fájlt..."
curl -L -o gradle/wrapper/gradle-wrapper.jar https://raw.githubusercontent.com/gradle/gradle/v8.4.0/gradle/wrapper/gradle-wrapper.jar

echo "[4/5] Létrehozom a gradlew futtatható scriptet..."
cat > gradlew <<'EOF'
#!/usr/bin/env bash
APP_HOME=$(cd "$(dirname "$0")" && pwd)
DEFAULT_JVM_OPTS=(-Xmx64m -Xms64m)
CLASSPATH="$APP_HOME/gradle/wrapper/gradle-wrapper.jar"
JAVA_CMD=${JAVA_HOME:-java}
exec "$JAVA_CMD" "${DEFAULT_JVM_OPTS[@]}" -cp "$CLASSPATH" org.gradle.wrapper.GradleWrapperMain "$@"
EOF

echo "[5/5] Futtathatóvá teszem a gradlew fájlt..."
chmod +x gradlew

echo "✅ Gradle wrapper sikeresen létrehozva!"
echo "Most már futtathatod: ./gradlew assembleDebug"
