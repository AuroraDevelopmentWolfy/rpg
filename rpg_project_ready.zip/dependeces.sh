#!/data/data/com.termux/files/usr/bin/bash

echo ">>> [1] JDK path:"
if command -v javac >/dev/null 2>&1; then
  which javac
  dirname $(readlink -f $(which javac))
else
  echo "JDK not found"
fi

echo ">>> [2] Java version:"
java -version 2>&1 | head -n 1

echo ">>> [3] Gradle version:"
if [ -f "./gradlew" ]; then
  ./gradlew --version | grep Gradle
else
  echo "gradlew not found in current directory"
fi

echo ">>> [4] Android SDK path:"
echo "$ANDROID_HOME"

echo ">>> [5] Build tools:"
ls "$ANDROID_HOME/build-tools" 2>/dev/null || echo "Not found"

echo ">>> [6] Platforms:"
ls "$ANDROID_HOME/platforms" 2>/dev/null || echo "Not found"

echo ">>> [7] NDK:"
ls "$ANDROID_HOME/ndk" 2>/dev/null || echo "NDK not found"

echo ">>> [8] ENV vars:"
echo "JAVA_HOME=$JAVA_HOME"
echo "ANDROID_HOME=$ANDROID_HOME"
echo "PATH=$PATH"

echo ">>> [9] Project root:"
pwd

echo ">>> [10] Gradle Wrapper exists:"
[ -f ./gradlew ] && echo "yes" || echo "no"

echo ">>> [11] settings.gradle exists:"
[ -f ./settings.gradle ] || [ -f ./settings.gradle.kts ] && echo "yes" || echo "no"

echo ">>> [12] build.gradle files:"
find . -name build.gradle -o -name build.gradle.kts

echo ">>> [13] App module exists:"
[ -d ./app ] && echo "yes" || echo "no"

echo ">>> [14] gradlew permissions:"
[ -f ./gradlew ] && ls -l ./gradlew | awk '{print $1}' || echo "not found"
