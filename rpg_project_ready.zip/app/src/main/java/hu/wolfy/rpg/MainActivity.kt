package hu.wolfy.rpg

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import hu.wolfy.rpg.ui.MainPagerAdapter

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val viewPager: ViewPager2 = findViewById(R.id.viewPager)
        val tabLayout: TabLayout = findViewById(R.id.tabLayout)

        val adapter = MainPagerAdapter(this)
        viewPager.adapter = adapter

        val tabTitles = listOf(
            getString(R.string.tab_character),
            getString(R.string.tab_inventory),
            getString(R.string.tab_shop),
            getString(R.string.tab_wilderness),
            getString(R.string.tab_arena),
            getString(R.string.tab_quests)
        )

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = tabTitles[position]
        }.attach()

        // Betöltés indításkor
        hu.wolfy.rpg.data.SaveManager.loadPlayer(this)

        // Mentés gomb
        findViewById<android.widget.Button>(R.id.btnSave).setOnClickListener {
            hu.wolfy.rpg.data.SaveManager.savePlayer(this)
        }
        // Betöltés gomb
        findViewById<android.widget.Button>(R.id.btnLoad).setOnClickListener {
            hu.wolfy.rpg.data.SaveManager.loadPlayer(this)
        }
    }
}
