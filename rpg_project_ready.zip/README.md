# RPG App (Android)

Ez a projekt automatikusan APK-t fordít minden `main` ágra történő push után a GitHub Actions segítségével.

## 🔧 Build eredménye

A buildelt `.apk` fájl elérhető lesz a [Actions](../../actions) oldalon `my-app-apk` néven.

## 📜 Futtatás

Telepítés után a `MainActivity.kt`-ben kezdődik az alkalmazás.
